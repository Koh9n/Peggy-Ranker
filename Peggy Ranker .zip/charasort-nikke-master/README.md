# charasort
A web based character sorter for Nikke. Allows users to run through a manual merge sort of their favorite
characters from a set.

Fork/based off of [Touhou Charcter Sorter](https://github.com/execfera/charasort)

## Related Sorters
Several others have created other sorters based on other concepts and series, see them [here](https://github.com/execfera/charasort/wiki)!

