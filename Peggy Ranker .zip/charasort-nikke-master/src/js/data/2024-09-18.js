dataSetVersion = "2024-02-22"; // Change this when creating a new data set version. YYYY-MM-DD format.
dataSet[dataSetVersion] = {};

// EXCLUDE

dataSet[dataSetVersion].options = [
    {
    name: "Exclude Black Ben Carson",
    key: "BBC",
    tooltip: "Exclude songs from Black Ben Carson",
    checked: false
  },
{
  name: "Exclude Veteran",
  key: "Veteran",
  tooltip: "Exclude songs from Veteran",
  checked: false
},
  
{
  name: "Exclude All My Heroes Are Cornballs",
  key: "AMHAC",
  tooltip: "Exclude songs from All My Heroes Are Cornballs",
  checked: false
},
{
  name: "Exclude EP!",
  key: "EP1",
  tooltip: "Exclude songs from EP!",
  checked: false
},
{
  name: "Exclude EP2!",
  key: "EP2",
  tooltip: "Exclude songs from Black Ben Carson",
  checked: false
},
{
  name: "Exclude LP!",
  key: "LP",
  tooltip: "Exclude songs from LP!",
  checked: true
},
{
  name: "Exclude Offline!",
  key: "OFF",
  tooltip: "Exclude songs from Offline!",
  checked: false
},
{
  name: "Exclude SCARING THE HOES",
  key: "STH",
  tooltip: "Exclude songs from SCARING THE HOES",
  checked: false
},
{
  name: "Exclude Scaring The Hoes: DLC Pack",
  key: "DLC",
  tooltip: "Exclude songs from Scaring The Hoes: DLC Pack",
  checked: false
},
{
  name: "Exclude I LAY DOWN MY LIFE FOR YOU",
  key: "ILDMLFY",
  tooltip: "Exclude songs from I LAY DOWN MY LIFE FOR YOU",
  checked: false
},
];

dataSet[dataSetVersion].characterData = [
  
  {
    name: "Drake Era",
    img: "7LlaUUl.jpeg",
    opts: {
	  BBC: true,
    }
  },
{
  name: "All Caps No Spaces",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "Digital Blackface",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
 {
  name: "Cuck",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "I Smell Crack",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "You Think You Know",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "Motor Mouth",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "Black Ben Carson",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "Black Steve Austin",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "Black Stacey Dash",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "What's Crackin",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "I Just Killed a Cop Now I'm Horny",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "Plastic",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "Boi (feat. Butch Dawson)",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "The 27 Club",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "Face Down Ass Up (feat. Freaky, Bito & Kente)",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "This That Shit Kid Cudi Coulda Been",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "2015 Was a Great Year",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "Try Me",
  img: "7LlaUUl.jpeg",
  opts: {
    BBC: true,
  }
},
{
  name: "1539 N.Calvert",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
  },
  {
  name: "Real Nega",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "Thug Tears",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "Dayum",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "Baby I'm Bleeding",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "My Thoughts on Neogaf Dying",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "Rock N Roll Is Dead",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "DD Form 214",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "Germs",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "Libtard Anthem",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "Panic Emoji",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "DJ Snitch Bitch Interlude",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "Whole Foods",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "Macaulay Culkin",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "Williamsburg",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "I Cannot Fucking Wait Til Morrissey Dies",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "Rainbow Six",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "1488",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "Curb Stomp",
  img: "iXpaZPm.jpeg",
  opts: {
    Veteran: true,
  }
},
{
  name: "Jesus Forgive Me, I Am a Thot",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "Kenan vs. Kel",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "Beta Male Strategies",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "JPEGMafia Type Beat",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "Grimy Waifu",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},{
  name: "PTSD",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "Rap Grow Old & Die x No Child Left Behind",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "All My Heroes Are Cornballs",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "BBW",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "Prone",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "Life's Hard, Here's a Song about Sorrel",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "Thot Tactics",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "Free the Frail (featuring Helena Deland)",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "Post Verified Lifestyle",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "BasicBitchTearGas",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "Dots Freestyle Remix (feat. Buzzy Lee & Abdu Ali)",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "Buttermilk Jesus Type Beat",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "Papi I Missed U",
  img: "y6bxWl3.jpeg",
  opts: {
    AMHAC: true,
  }
},
{
  name: "Bald",
  img: "yXFYV1c.jpeg",
  opts: {
    EP1: true,
  }
},
{
  name: "Covered In Money!",
  img: "yXFYV1c.jpeg",
  opts: {
    EP1: true,
  }
},
{
  name: "Bodyguard!",
  img: "yXFYV1c.jpeg",
  opts: {
    EP1: true,
  }
},
{
  name: "Bald! Remix",
  img: "yXFYV1c.jpeg",
  opts: {
    EP1: true,
  }
},
{
  name: "Cutie Pie!",
  img: "yXFYV1c.jpeg",
  opts: {
    EP1: true,
  }
},
{
  name: "The Bends!",
  img: "yXFYV1c.jpeg",
  opts: {
    EP1: true,
  }
},
{
  name: "Rough 7",
  img: "yXFYV1c.jpeg",
  opts: {
    EP1: true,
  }
},
{
  name: "Living Single",
  img: "yXFYV1c.jpeg",
  opts: {
    EP1: true,
  }
},
{
  name: "Super Tuesday!",
  img: "yXFYV1c.jpeg",
  opts: {
    EP1: true,
  }
},
{
  name: "LAST DANCE!",
  img: "YT2eP3Z.jpeg",
  opts: {
    EP2: true,
  }
},
{
  name: "FIX URSELF!",
  img: "YT2eP3Z.jpeg",
  opts: {
    EP2: true,
  }
},
{
  name: "KELTEC!",
  img: "YT2eP3Z.jpeg",
  opts: {
    EP2: true,
  }
},
{
  name: "THIS ONES FOR US!",
  img: "YT2eP3Z.jpeg",
  opts: {
    EP2: true,
  }
},
{
  name: "PANIC ROOM!",
  img: "YT2eP3Z.jpeg",
  opts: {
    EP2: true,
  }
},
{
  name: "FEED HER!",
  img: "YT2eP3Z.jpeg",
  opts: {
    EP2: true,
  }
},
{
  name: "Trust!",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "Dirty!",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "Nemo!",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "End Credits!",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},{
  name: "What Kind of Rappin' Is This?",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "Thot's Prayer!",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "Are U Happy?",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "Rebound!",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "OG!",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "Dam! Dam! Dam!",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "Sick, Nervous & Broke!",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "Kissy Face Emoji!",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "Nice!",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "BMT!",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "The Ghost of Ranking Dread!",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "Cutie Pie!",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "Bald!",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "Bald! Remix",
  img: "NVDVm1b.jpeg",
  opts: {
    LP: true,
  }
},
{
  name: "TRUST! (OFFLINE)",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "DIRTY! (OFFLINE)",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "NEMO (OFFLINE)",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "End Credits! (OFFLINE)",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "Hazard Duty Pay!",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "God Don't Like Ugly!",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "What Kinda Rappin' Is This? (OFFLINE)",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "Thot's Prayer! (OG MIX)",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "Are You Happy?",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "REBOUND (feat. DATPIFFMAFIA) - OFFLINE ",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "100 Emoji! (INSTRUMENTAL)",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "Og! (OFFLINE)",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "Dikembe!",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "TIRED, NERVOUS & BROKE (feat. Kimbra)",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "Flame Emoji!",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "Nice (OG MIX)",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "Bmt (OFFLINE)",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "The GHOST of RANKING DREAD! (feat. Tkay Maidza) - OFFLINE",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "Dam! Dam! Dam! (OFFLINE)",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "Untitled",
  img: "R8B6PJu.jpeg",
  opts: {
    OFF: true,
  }
},
{
  name: "Lean Beef Patty",
  img: "BIf8Mul.jpeg",
  opts: {
    STH: true,
  }
},
{
  name: "Steppa Pig",
  img: "BIf8Mul.jpeg",
  opts: {
    STH: true,
  }
},
{
  name: "Scaring the Hoes",
  img: "BIf8Mul.jpeg",
  opts: {
    STH: true,
  }
},
{
  name: "Garbage Pale Kids",
  img: "BIf8Mul.jpeg",
  opts: {
    STH: true,
  }
},
{
  name: "Fentanyl Tester",
  img: "BIf8Mul.jpeg",
  opts: {
    STH: true,
  }
},
{
  name: "Burfict",
  img: "BIf8Mul.jpeg",
  opts: {
    STH: true,
  }
},
{
  name: "Shut Yo Bitch Ass Up / Muddy Waters",
  img: "BIf8Mul.jpeg",
  opts: {
    STH: true,
  }
},
{
  name: "Orange Juice Jones",
  img: "BIf8Mul.jpeg",
  opts: {
    STH: true,
  }
},
{
  name: "Kingdom Hearts Key (feat. redveil)",
  img: "BIf8Mul.jpeg",
  opts: {
    STH: true,
  }
},
{
  name: "God Loves You",
  img: "BIf8Mul.jpeg",
  opts: {
    STH: true,
  }
},
{
  name: "Run the Jewels",
  img: "BIf8Mul.jpeg",
  opts: {
    STH: true,
  }
},
{
  name: "Jack Harlow Combo Meal",
  img: "BIf8Mul.jpeg",
  opts: {
    STH: true,
  }
},
{
  name: "HOE (Heaven on Earth)",
  img: "BIf8Mul.jpeg",
  opts: {
    STH: true,
  }
},
{
  name: "Where Ya Get Ya Coke From?",
  img: "BIf8Mul.jpeg",
  opts: {
    STH: true,
  }
},
{
  name: "Guess What Bitch, We Back Hoe!",
  img: "38EIdpC.jpg",
  opts: {
    DLC: true,
  }
},
{
  name: "HERMANOS",
  img: "38EIdpC.jpg",
  opts: {
    DLC: true,
  }
},
{
  name: "Tell Me Where To Go",
  img: "38EIdpC.jpg",
  opts: {
    DLC: true,
  }
},
{
  name: "NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO! NO!",
  img: "38EIdpC.jpg",
  opts: {
    DLC: true,
  }
},
{
  name: "I Scream This in the Mirror Before I Interact with Anyone",
  img: "7OW2ZVI.jpeg",
  opts: {
    ILDMLFY: true,
  }
},
{
  name: "SIN MIEDO",
  img: "7OW2ZVI.jpeg",
  opts: {
    ILDMLFY: true,
  }
},
{
  name: "I'll Be Right There",
  img: "7OW2ZVI.jpeg",
  opts: {
    ILDMLFY: true,
  }
},
{
  name: "it's dark and hell is hot",
  img: "7OW2ZVI.jpeg",
  opts: {
    ILDMLFY: true,
  }
},
{
  name: "New Black History (feat. Vince Staples)",
  img: "7OW2ZVI.jpeg",
  opts: {
    ILDMLFY: true,
  }
},
{
  name: "don't rely on other men - album version",
  img: "7OW2ZVI.jpeg",
  opts: {
    ILDMLFY: true,
  }
},
{
  name: "vulgar display of power",
  img: "7OW2ZVI.jpeg",
  opts: {
    ILDMLFY: true,
  }
},
{
  name: "Exmilitary",
  img: "7OW2ZVI.jpeg",
  opts: {
    ILDMLFY: true,
  }
},
{
  name: "JIHAD JOE",
  img: "7OW2ZVI.jpeg",
  opts: {
    ILDMLFY: true,
  }
},
{
  name: "JPEGULTRA! (feat. Denzel Curry)",
  img: "7OW2ZVI.jpeg",
  opts: {
    ILDMLFY: true,
  }
},
{
  name: "either on or off the drugs",
  img: "7OW2ZVI.jpeg",
  opts: {
    ILDMLFY: true,
  }
},
{
  name: "loop it and leave it",
  img: "7OW2ZVI.jpeg",
  opts: {
    ILDMLFY: true,
  }
},
{
  name: "Don't Put Anything On the Bible (feat. Buzzy Lee)",
  img: "7OW2ZVI.jpeg",
  opts: {
    ILDMLFY: true,
  }
},
{
  name: "i recovered from this",
  img: "7OW2ZVI.jpeg",
  opts: {
    ILDMLFY: true,
  }
},
];
